Direcly download and extract the zip file to get all the files properly.
