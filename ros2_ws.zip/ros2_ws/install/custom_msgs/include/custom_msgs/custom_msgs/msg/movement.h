// generated from rosidl_generator_c/resource/idl.h.em
// with input from custom_msgs:msg/Movement.idl
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__MOVEMENT_H_
#define CUSTOM_MSGS__MSG__MOVEMENT_H_

#include "custom_msgs/msg/detail/movement__struct.h"
#include "custom_msgs/msg/detail/movement__functions.h"
#include "custom_msgs/msg/detail/movement__type_support.h"

#endif  // CUSTOM_MSGS__MSG__MOVEMENT_H_
