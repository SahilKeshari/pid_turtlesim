// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CUSTOM_MSGS__MSG__MOVEMENT_HPP_
#define CUSTOM_MSGS__MSG__MOVEMENT_HPP_

#include "custom_msgs/msg/detail/movement__struct.hpp"
#include "custom_msgs/msg/detail/movement__builder.hpp"
#include "custom_msgs/msg/detail/movement__traits.hpp"

#endif  // CUSTOM_MSGS__MSG__MOVEMENT_HPP_
